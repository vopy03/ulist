<?php

return [
    'enable' => true,
    'driver' => 'mysql',
    'host' => 'localhost',
    'dbname' => 'ulist',
    'user' => 'root',
    'password' => '',
    'charset' => 'utf8'
];
