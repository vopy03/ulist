<div class="actionbar-container">

  <button class="btn btn-success" type="button" id="add-user-btn" data-toggle="modal" data-target="#user-form-modal">Add</button>
  <form method="post" class="action-form">
    <select class="custom-select" name="action" id="actionSelect">
      <option selected>-Please Select-</option>
      <option value="1">Set active</option>
      <option value="2">Set not active</option>
      <option value="3">Delete</option>
    </select>
    <button class="btn btn-primary" type="submit">Ok</button>
  </form>
</div>