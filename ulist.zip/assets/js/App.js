
class App {

    static init() {

        Actionbar.init();
        Selection.init();
        Modal.init();
        List.init();
    }

}