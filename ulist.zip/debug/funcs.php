<?php

function pr($s) {
    echo  "<pre>";
    print_r($s);
    echo  "</pre>";
}