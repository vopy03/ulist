<!DOCTYPE html>
<html>
<?php require_once 'views/components/head.php';?>
<body>
<?php require_once 'views/components/navbar.php';?>
<div class="container d-flex justify-content-center">
    <h1 class="mt-4">500 Server Error</h1>
</div>
</body>
</html>